# 🏋️ FitOnFit — Workout & Nutrition Tracker

A full-stack style frontend web application for tracking workouts, nutrition, and fitness progress.

## 🚀 Tech Stack
- **Frontend:** HTML5, CSS3, JavaScript (ES6+)
- **Storage:** localStorage (simulates a REST API database)
- **Charts:** Chart.js
- **Auth:** JWT-style session via localStorage

---

## 📁 Project Structure

```
FitOnFit/
├── index.html              ← Landing page + Login/Register
├── css/
│   └── style.css           ← All styles
├── js/
│   └── app.js              ← Auth, Storage, Utility functions
└── pages/
    ├── dashboard.html      ← Main dashboard with stats
    ├── workout.html        ← Workout tracker
    ├── nutrition.html      ← Nutrition/meal tracker
    └── progress.html       ← Progress charts & goals
```

---

## ▶️ Run Locally (VS Code)

### Option 1: Live Server (Recommended)
1. Open the `FitOnFit` folder in VS Code
2. Install the **Live Server** extension (by Ritwick Dey)
3. Right-click `index.html` → **"Open with Live Server"**
4. App opens at `http://127.0.0.1:5500`

### Option 2: Simple browser
1. Just double-click `index.html` to open in browser
   *(Note: some browsers may restrict localStorage on file:// protocol — use Live Server for best experience)*

---

## 🌐 Deploy to GitHub Pages

1. **Create a GitHub repository** (e.g., `FitOnFit`)

2. **Push your code:**
```bash
git init
git add .
git commit -m "Initial commit: FitOnFit app"
git remote add origin https://github.com/YOUR_USERNAME/FitOnFit.git
git push -u origin main
```

3. **Enable GitHub Pages:**
   - Go to your repo → **Settings** → **Pages**
   - Source: `Deploy from a branch`
   - Branch: `main` / `root`
   - Click **Save**

4. **Your site will be live at:**
   `https://YOUR_USERNAME.github.io/FitOnFit/`

---

## ✨ Features

| Feature | Description |
|---|---|
| 🔐 Auth | Register/Login with password hashing (btoa) |
| 🏋️ Workout Tracker | Log 12+ workout types, auto-calorie estimation |
| 🥗 Nutrition Tracker | Log meals by type with macros (protein, carbs, fat) |
| 📊 Progress Charts | Line, bar & donut charts (Chart.js) |
| 🎯 Goal Setting | Set daily calorie, protein & workout goals |
| 📅 Date Navigation | View/log nutrition for any past date |
| 🔥 Streak Tracking | Tracks consecutive days of activity |
| 📱 Responsive | Works on mobile and desktop |

---

## 🔧 REST API Simulation

The app simulates REST API behavior using localStorage:

| Simulated Endpoint | Function |
|---|---|
| POST /auth/register | `Auth.register()` |
| POST /auth/login | `Auth.login()` |
| GET /workouts | `WorkoutDB.getAll()` |
| POST /workouts | `WorkoutDB.add()` |
| DELETE /workouts/:id | `WorkoutDB.delete()` |
| GET /nutrition | `NutritionDB.getAll()` |
| POST /nutrition | `NutritionDB.add()` |
| GET/PUT /goals | `GoalsDB.get/set()` |

---

## 👩‍💻 Developer

**Bhuvana M** — Full Stack Developer (Fresher, 2026)  
📧 m.bhuvana6384@gmail.com  
🔗 [LinkedIn](https://www.linkedin.com/in/bhuvana-m-234762328)  
💻 [GitHub](https://github.com/Bhuvanabhuvi22)
