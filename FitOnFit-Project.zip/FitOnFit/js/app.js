// ── FitOnFit Storage & Auth Utility ──

const DB = {
  get(key) {
    try { return JSON.parse(localStorage.getItem(key)); } catch { return null; }
  },
  set(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
  },
  remove(key) { localStorage.removeItem(key); }
};

// ── AUTH ──
const Auth = {
  currentUser() {
    return DB.get('fof_current_user');
  },
  login(email, password) {
    const users = DB.get('fof_users') || [];
    const user = users.find(u => u.email === email && u.password === btoa(password));
    if (!user) return { ok: false, msg: 'Invalid email or password.' };
    DB.set('fof_current_user', { id: user.id, name: user.name, email: user.email });
    return { ok: true };
  },
  register(name, email, password) {
    const users = DB.get('fof_users') || [];
    if (users.find(u => u.email === email)) return { ok: false, msg: 'Email already registered.' };
    const user = { id: Date.now().toString(), name, email, password: btoa(password), createdAt: new Date().toISOString() };
    users.push(user);
    DB.set('fof_users', users);
    DB.set('fof_current_user', { id: user.id, name: user.name, email: user.email });
    return { ok: true };
  },
  logout() { DB.remove('fof_current_user'); window.location.href = '../index.html'; },
  require() {
    if (!Auth.currentUser()) window.location.href = '../index.html';
  }
};

// ── WORKOUT DATA ──
const WorkoutDB = {
  _key(uid) { return `fof_workouts_${uid}`; },
  getAll() {
    const u = Auth.currentUser(); if (!u) return [];
    return DB.get(WorkoutDB._key(u.id)) || [];
  },
  add(entry) {
    const u = Auth.currentUser(); if (!u) return;
    const all = WorkoutDB.getAll();
    all.unshift({ id: Date.now().toString(), ...entry, date: entry.date || new Date().toISOString().split('T')[0] });
    DB.set(WorkoutDB._key(u.id), all);
  },
  delete(id) {
    const u = Auth.currentUser(); if (!u) return;
    const all = WorkoutDB.getAll().filter(w => w.id !== id);
    DB.set(WorkoutDB._key(u.id), all);
  },
  getToday() {
    const today = new Date().toISOString().split('T')[0];
    return WorkoutDB.getAll().filter(w => w.date === today);
  },
  getThisWeek() {
    const d = new Date(); d.setDate(d.getDate() - 6);
    const from = d.toISOString().split('T')[0];
    return WorkoutDB.getAll().filter(w => w.date >= from);
  }
};

// ── NUTRITION DATA ──
const NutritionDB = {
  _key(uid) { return `fof_nutrition_${uid}`; },
  getAll() {
    const u = Auth.currentUser(); if (!u) return [];
    return DB.get(NutritionDB._key(u.id)) || [];
  },
  add(entry) {
    const u = Auth.currentUser(); if (!u) return;
    const all = NutritionDB.getAll();
    all.unshift({ id: Date.now().toString(), ...entry, date: entry.date || new Date().toISOString().split('T')[0] });
    DB.set(NutritionDB._key(u.id), all);
  },
  delete(id) {
    const u = Auth.currentUser(); if (!u) return;
    const all = NutritionDB.getAll().filter(n => n.id !== id);
    DB.set(NutritionDB._key(u.id), all);
  },
  getToday() {
    const today = new Date().toISOString().split('T')[0];
    return NutritionDB.getAll().filter(n => n.date === today);
  }
};

// ── GOALS ──
const GoalsDB = {
  _key(uid) { return `fof_goals_${uid}`; },
  get() {
    const u = Auth.currentUser(); if (!u) return {};
    return DB.get(GoalsDB._key(u.id)) || { calories: 2000, protein: 120, workoutsPerWeek: 4 };
  },
  set(goals) {
    const u = Auth.currentUser(); if (!u) return;
    DB.set(GoalsDB._key(u.id), goals);
  }
};

// ── HELPERS ──
function formatDate(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function initNav() {
  const user = Auth.currentUser();
  const av = document.getElementById('nav-avatar');
  const nm = document.getElementById('nav-name');
  if (av && user) av.textContent = user.name.charAt(0).toUpperCase();
  if (nm && user) nm.textContent = user.name.split(' ')[0];
}

function setActive(id) {
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
}

const WORKOUT_TYPES = [
  'Running', 'Walking', 'Cycling', 'Swimming', 'Yoga',
  'Weight Training', 'HIIT', 'Pilates', 'CrossFit',
  'Jump Rope', 'Stretching', 'Other'
];

const MEAL_TYPES = ['Breakfast', 'Lunch', 'Dinner', 'Snack'];

// Calorie burn estimates per min
const CAL_PER_MIN = {
  'Running': 10, 'Walking': 5, 'Cycling': 8, 'Swimming': 9,
  'Yoga': 3, 'Weight Training': 6, 'HIIT': 12, 'Pilates': 4,
  'CrossFit': 11, 'Jump Rope': 11, 'Stretching': 2, 'Other': 5
};
